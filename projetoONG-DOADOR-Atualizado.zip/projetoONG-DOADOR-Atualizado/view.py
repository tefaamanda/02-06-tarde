import re
from flask import Flask, jsonify, request, send_file, session, send_from_directory
from main import app, con
from flask_bcrypt import generate_password_hash, check_password_hash
from fpdf import FPDF
from flask import request
import os
import jwt
from flask_cors import CORS
import qrcode
from io import BytesIO
import crcmod
from datetime import datetime
import random

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
import locale
try:
    locale.setlocale(locale.LC_TIME, 'pt_BR.UTF-8')
except locale.Error:
    pass

meses = [
    "janeiro", "fevereiro", "março", "abril", "maio", "junho",
    "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"
]

CORS(app, resources={r"/": {"origins": "*"}},  # Permite todas as origens
     allow_headers=["Content-Type", "Authorization"],
     methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"])

# CADASTRO
app.config.from_pyfile('config.py')

senha_secreta = app.config['SECRET_KEY']

if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])


def generate_token(user_id, email):
    # Esse payload armazena os dados que vão incorporar no token (aqui é o ID)
    payload = {'id_usuario': user_id, 'email': email}
    # Geração do token com o algoritmo de hash HS256 usando uma senha secreta
    token = jwt.encode(payload, senha_secreta, algorithm='HS256')
    # Retorna o token
    return token


def remover_bearer(token):
    # Verifica se o token começa com a string 'Bearer '
    if token.startswith('Bearer '):
        # retorna sem a parte 'Bearer '
        return token[len('Bearer '):]
    else:
        return token

@app.route('/doadores', methods=['GET'])
def doadores():
    cur = con.cursor()

    cur.execute(
        "SELECT id_usuario, nome, e_mail, senha, tipo, ativo FROM usuario WHERE tipo = 3")
    usuarios = cur.fetchall()
    cur.close()
    usuarios_dic = []

    for usuario in usuarios:
        id_usuario = usuario[0]
        nome = usuario[1]
        e_mail = usuario[2]
        senha = usuario[3]
        tipo = usuario[4]
        ativo = usuario[5]

        usuarios_dic.append({
            'id_usuario': id_usuario,
            'nome': nome,
            'e_mail': e_mail,
            'senha': senha,
            'tipo': tipo,
            'ativo': ativo
        })

    if usuarios_dic:
        return jsonify(mensagem='Registro de Cadastro de Usuários', usuarios=usuarios_dic)
    else:
        return jsonify(mensagem='Nenhum dado encontrado')

@app.route('/ongs', methods=['GET'])
def ongs():
    cur = con.cursor()

    cur.execute(
        "SELECT id_usuario, nome, e_mail, senha, tipo, ativo, cnpj, categoria, descricao_da_causa, cep, chave_pix, num_agencia, num_conta, nome_banco, endereco, complemento, nome_resp, telefone, site_url, facebook, instagram, cidade, aprovada FROM usuario WHERE tipo = 2")
    usuarios = cur.fetchall()
    cur.close()
    usuarios_dic = []

    for usuario in usuarios:
        id_usuario = usuario[0]
        nome = usuario[1]
        e_mail = usuario[2]
        senha = usuario[3]
        tipo = usuario[4]
        ativo = usuario[5]
        cnpj = usuario[6]
        categoria = usuario[7]
        descricao_da_causa = usuario[8]
        cep = usuario[9]
        chave_pix = usuario[10]
        num_agencia = usuario[11]
        num_conta = usuario[12]
        nome_banco = usuario[13]
        endereco = usuario[14]
        complemento = usuario[15]
        nome_resp = usuario[16]
        telefone = usuario[17]
        site_url = usuario[18]
        facebook = usuario[19]
        instagram = usuario[20]
        cidade = usuario[21]
        aprovada = usuario[22]

        usuarios_dic.append({
            'id_usuario': id_usuario,
            'nome': nome,
            'e_mail': e_mail,
            'senha': senha,
            'tipo': tipo,
            'ativo': ativo,
            'cnpj': cnpj,
            'categoria': categoria,
            'descricao_da_causa': descricao_da_causa,
            'cep': cep,
            'chave_pix': chave_pix,
            'num_agencia': num_agencia,
            'num_conta': num_conta,
            'nome_banco': nome_banco,
            'endereco': endereco,
            'complemento': complemento,
            'nome_resp': nome_resp,
            'telefone': telefone,
            'site_url': site_url,
            'facebook': facebook,
            'instagram': instagram,
            'cidade': cidade,
            'aprovada': aprovada
        })

    if usuarios_dic:
        return jsonify(mensagem='Registro de Cadastro de Usuários', usuarios=usuarios_dic)
    else:
        return jsonify(mensagem='Nenhum dado encontrado')


def validar_senha(senha):
    padrao = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%¨&*])(?=.*\d).{8,}$'

    if re.fullmatch(padrao, senha):
        return True
    else:
        return False


@app.route('/ongs_explorar', methods=['GET'])
def ongs_explorar():
    cur = con.cursor()

    cur.execute(
        "SELECT id_usuario, nome, e_mail, senha, tipo, ativo, cnpj, categoria, descricao_da_causa, cep, chave_pix, num_agencia, num_conta, nome_banco, endereco, complemento, nome_resp, telefone, site_url, facebook, instagram, cidade, aprovada FROM usuario WHERE tipo = 2 AND aprovada = 1 AND ativo = 1")
    usuarios = cur.fetchall()
    cur.close()
    usuarios_dic = []

    for usuario in usuarios:
        id_usuario = usuario[0]
        nome = usuario[1]
        e_mail = usuario[2]
        senha = usuario[3]
        tipo = usuario[4]
        ativo = usuario[5]
        cnpj = usuario[6]
        categoria = usuario[7]
        descricao_da_causa = usuario[8]
        cep = usuario[9]
        chave_pix = usuario[10]
        num_agencia = usuario[11]
        num_conta = usuario[12]
        nome_banco = usuario[13]
        endereco = usuario[14]
        complemento = usuario[15]
        nome_resp = usuario[16]
        telefone = usuario[17]
        site_url = usuario[18]
        facebook = usuario[19]
        instagram = usuario[20]
        cidade = usuario[21]
        aprovada = usuario[22]

        usuarios_dic.append({
            'id_usuario': id_usuario,
            'nome': nome,
            'e_mail': e_mail,
            'senha': senha,
            'tipo': tipo,
            'ativo': ativo,
            'cnpj': cnpj,
            'categoria': categoria,
            'descricao_da_causa': descricao_da_causa,
            'cep': cep,
            'chave_pix': chave_pix,
            'num_agencia': num_agencia,
            'num_conta': num_conta,
            'nome_banco': nome_banco,
            'endereco': endereco,
            'complemento': complemento,
            'nome_resp': nome_resp,
            'telefone': telefone,
            'site_url': site_url,
            'facebook': facebook,
            'instagram': instagram,
            'cidade': cidade,
            'aprovada': aprovada
        })

    if usuarios_dic:
        return jsonify(mensagem='Registro de Cadastro de Usuários', usuarios=usuarios_dic)
    else:
        return jsonify(mensagem='Nenhum dado encontrado')

@app.route('/ongs_aleatorias', methods=['GET'])
def ongs_aleatorias():
    cur = con.cursor()

    cur.execute("SELECT id_usuario, nome, e_mail, senha, tipo, ativo, cnpj, categoria, descricao_da_causa, cep, chave_pix, num_agencia, num_conta, nome_banco, endereco, complemento, nome_resp, telefone, site_url, facebook, instagram, cidade, aprovada FROM usuario WHERE tipo = 2 AND aprovada = 1 AND ativo = 1")
    todos_usuarios = cur.fetchall()
    cur.close()
    usuarios = random.sample(todos_usuarios, min(3, len(todos_usuarios)))

    usuarios_dic = []
    for usuario in usuarios:
        usuarios_dic.append({
            'id_usuario': usuario[0],
            'nome': usuario[1],
            'e_mail': usuario[2],
            'senha': usuario[3],
            'tipo': usuario[4],
            'ativo': usuario[5],
            'cnpj': usuario[6],
            'categoria': usuario[7],
            'descricao_da_causa': usuario[8],
            'cep': usuario[9],
            'chave_pix': usuario[10],
            'num_agencia': usuario[11],
            'num_conta': usuario[12],
            'nome_banco': usuario[13],
            'endereco': usuario[14],
            'complemento': usuario[15],
            'nome_resp': usuario[16],
            'telefone': usuario[17],
            'site_url': usuario[18],
            'facebook': usuario[19],
            'instagram': usuario[20],
            'cidade': usuario[21],
            'aprovada': usuario[22]
        })

    if usuarios_dic:
        return jsonify(mensagem='3 ONGs aleatórias', usuarios=usuarios_dic)
    else:
        return jsonify(mensagem='Nenhum dado encontrado')


@app.route('/cadastro', methods=['POST'])
def cadastro_post():
    data = request.get_json()
    nome = data.get('nome')
    e_mail = data.get('e_mail')
    senha = data.get('senha')
    cnpj = data.get('cnpj')
    categoria = data.get('categoria')
    descricao_da_causa = data.get('descricao_da_causa')
    cep = data.get('cep')
    chave_pix = data.get('chave_pix')
    num_agencia = data.get('num_agencia')
    num_conta = data.get('num_conta')
    nome_banco = data.get('nome_banco')
    endereco = data.get('endereco')
    complemento = data.get('complemento')
    nome_resp = data.get('nome_resp')
    telefone = data.get('telefone')
    site_url = data.get('site_url')
    facebook = data.get('facebook')
    instagram = data.get('instagram')
    cidade = data.get('cidade')
    tipo_usuario = int(data.get('tipo'))

    if not validar_senha(senha):
        return jsonify({
                           "error": 'A sua senha precisa ter pelo menos 8 caracteres, uma letra maiúscula, uma letra minúscula, um número e um caractere especial.'}), 401

    cursor = con.cursor()
    try:
        cursor.execute("SELECT 1 FROM usuario WHERE E_MAIL = ?", (e_mail,))
        if cursor.fetchone():
            return jsonify({"error": "E-mail já cadastrado!"}), 400

        senha = generate_password_hash(senha).decode('utf-8')

        if tipo_usuario == 3:
            cursor.execute("INSERT INTO USUARIO(NOME, E_MAIL, SENHA, tipo, ativo, aprovada) VALUES (?, ?, ?, ?, ?, 0)",
                           (nome, e_mail, senha, 3, 1))
            con.commit()

            return jsonify({
                'message': "Registro realizado com sucesso!",
                'usuario': {
                    'nome': nome,
                    'e_mail': e_mail,
                    'senha': senha
                }
            })

        elif tipo_usuario == 2:
            cursor.execute(
                "INSERT INTO USUARIO(NOME, E_MAIL, SENHA, CNPJ, CATEGORIA, DESCRICAO_DA_CAUSA, CEP, CHAVE_PIX, NUM_AGENCIA, NUM_CONTA, NOME_BANCO, ATIVO, TIPO, ENDERECO, COMPLEMENTO, NOME_RESP, TELEFONE, SITE_URL, FACEBOOK, INSTAGRAM, CIDADE, APROVADA) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (nome, e_mail, senha, cnpj, categoria, descricao_da_causa, cep, chave_pix, num_agencia, num_conta,
                 nome_banco, 1, 2, endereco, complemento, nome_resp, telefone, site_url, facebook, instagram, cidade, 0))
            con.commit()
            return jsonify({
                'message': "Registro realizado com sucesso!",
                'usuario': {
                    'nome': nome,
                    'e_mail': e_mail,
                    'senha': senha,
                    'cnpj': cnpj,
                    'categoria': categoria,
                    'descricao_da_causa': descricao_da_causa,
                    'cep': cep,
                    'chave_pix': chave_pix,
                    'num_agencia': num_agencia,
                    'num_conta': num_conta,
                    'nome_banco': nome_banco,
                    'endereco': endereco,
                    'complemento': complemento,
                    'nome_resp': nome_resp,
                    'telefone': telefone,
                    'site_url': site_url,
                    'facebook': facebook,
                    'instagram': instagram,
                    'cidade': cidade
                }
            })
        elif tipo_usuario == 1:
            cursor.execute("INSERT INTO USUARIO(NOME, E_MAIL, SENHA, tipo, ativo) VALUES (?, ?, ?, ?, ?)",
                           (nome, e_mail, senha, 1, 1))
            con.commit()

            return jsonify({
                'message': "Registro realizado com sucesso!",
                'usuario': {
                    'nome': nome,
                    'e_mail': e_mail,
                    'senha': senha
                }
            })
        else:
            return jsonify({
                'error': "Tipo Selecionado Inválido!"
            }), 400

    finally:
        if cursor:
            cursor.close()


@app.route('/cadastro/<int:id>', methods=['DELETE'])
def deletar_cadastro(id):
    cursor = con.cursor()
    cursor.execute("SELECT 1 FROM usuario WHERE ID_USUARIO = ?", (id,))
    if not cursor.fetchone():
        cursor.close()
        return jsonify({"error": "Registro não encontrado."}), 404

    cursor.execute("DELETE FROM usuario WHERE ID_USUARIO = ?", (id,))
    con.commit()
    cursor.close()

    return jsonify({
        'message': "Cadastro excluído com sucesso!",
        'id_usuario': id
    })


@app.route('/cadastro/<int:id>', methods=['PUT'])
def cadastro_put(id):
    cursor = con.cursor()
    try:
        cripto = 0
        tipo_usuario = request.args.get('tipo',
                                        type=int)  # Essa linha utiliza 'request.args.get' para adquirir o valor do tipo armazenado no banco de dados, vimos sobre esse código no site: https://stackoverflow.com/questions/34671217/in-flask-what-is-request-args-and-how-is-it-used
        cursor.execute(
            "select id_usuario, nome, e_mail, senha, cnpj, categoria, descricao_da_causa, cep, chave_pix, num_agencia, num_conta, nome_banco, tipo, endereco, complemento, nome_resp, telefone, site_url, facebook, instagram, cidade, ativo from usuario WHERE id_usuario = ?",
            (id,))
        usuario = cursor.fetchone()

        tipo_usuario = usuario[12]
        senha_armazenada = usuario[3]
        e_mail_armazenado = usuario[2]
        nome_armazenado = usuario[1]
        cnpj_armazenado = usuario[4]
        categoria_armazenada = usuario[5]
        descricao_armazenada = usuario[6]
        cep_armazenado = usuario[7]
        chave_pix_armazenado = usuario[8]
        num_agencia_armazenado = usuario[9]
        num_conta_armazenado = usuario[10]
        nome_banco_armazenado = usuario[11]
        endereco_armazenado = usuario[13]
        complemento_armazenado = usuario[14]
        nome_resp_armazenado = usuario[15]
        telefone_armazenado = usuario[16]
        site_url_armazenado = usuario[17]
        facebook_armazenado = usuario[18]
        instagram_armazenado = usuario[19]
        cidade_armazenada = usuario[20]
        atividade_armazenada = usuario[21]

        if not usuario:
            return jsonify({"error": 'Registro não encontrado.'}), 401

        if tipo_usuario == 3:
            data = request.get_json()
            nome = data.get('nome')
            e_mail = data.get('e_mail')
            senha = data.get('senha')
            tipo = data.get('tipo')
            ativo = data.get('ativo')

            if senha is None:
                cripto = 1
                senha = senha_armazenada

            if tipo is None:
                tipo = tipo_usuario

            if ativo is None:
                ativo = atividade_armazenada


            if e_mail_armazenado != e_mail:
                cursor.execute("SELECT 1 FROM usuario WHERE E_MAIL = ?", (e_mail,))
                if cursor.fetchone():
                    return jsonify({"error": "E-mail já cadastrado!"}), 400

            if senha_armazenada != senha:
                if not validar_senha(senha):
                    return jsonify({
                                       "error": 'A sua senha precisa ter pelo menos 8 caracteres, uma letra maiúscula, uma letra minúscula, um número e um caractere especial.'}), 401

            if senha is not None and cripto != 1:
                senha = generate_password_hash(senha).decode('utf-8')

            cursor.execute("UPDATE usuario SET NOME = ?, E_MAIL = ?, senha = ?, TIPO = ?, ATIVO = ? WHERE ID_USUARIO = ?",
                           (nome, e_mail, senha, tipo, ativo, id))
            con.commit()

            return jsonify({
                'message': "Cadastro atualizado com sucesso!",
                'usuario': {
                    'id_usuario': id,
                    'nome': nome,
                    'e_mail': e_mail,
                    'senha': senha,
                    'tipo': tipo,
                    'ativo': ativo
                }
            }), 200

        elif tipo_usuario == 1:
            data = request.get_json()
            nome = data.get('nome')
            e_mail = data.get('e_mail')
            senha = data.get('senha')
            tipo = data.get('tipo')
            ativo = data.get('ativo')

            if senha is None:
                cripto = 1
                senha = senha_armazenada


            if e_mail_armazenado != e_mail:
                cursor.execute("SELECT 1 FROM usuario WHERE E_MAIL = ?", (e_mail,))
                if cursor.fetchone():
                    return jsonify({"error": "E-mail já cadastrado!"}), 400

            if senha_armazenada != senha:
                if not validar_senha(senha):
                    return jsonify({
                                       "error": 'A sua senha precisa ter pelo menos 8 caracteres, uma letra maiúscula, uma letra minúscula, um número e um caractere especial.'}), 401

            if senha is not None and cripto != 1:
                senha = generate_password_hash(senha).decode('utf-8')

            cursor.execute("UPDATE usuario SET NOME = ?, E_MAIL = ?, senha = ?, TIPO = ?, ATIVO = ? WHERE ID_USUARIO = ?",
                           (nome, e_mail, senha, tipo, ativo, id))
            con.commit()

            return jsonify({
                'message': "Cadastro atualizado com sucesso!",
                'usuario': {
                    'id_usuario': id,
                    'nome': nome,
                    'e_mail': e_mail,
                    'senha': senha,
                    'tipo': tipo,
                    'ativo': ativo
                }
            }), 200

        elif tipo_usuario == 2:
            data = request.get_json()
            nome = data.get('nome')
            e_mail = data.get('e_mail')
            senha = data.get('senha')
            cnpj = data.get('cnpj')
            categoria = data.get('categoria')
            descricao_da_causa = data.get('descricao_da_causa')
            cep = data.get('cep')
            chave_pix = data.get('chave_pix')
            num_agencia = data.get('num_agencia')
            num_conta = data.get('num_conta')
            nome_banco = data.get('nome_banco')
            endereco = data.get('endereco')
            complemento = data.get('complemento')
            nome_resp = data.get('nome_resp')
            telefone = data.get('telefone')
            site_url = data.get('site_url')
            facebook = data.get('facebook')
            instagram = data.get('instagram')
            cidade = data.get('cidade')
            tipo = data.get('tipo')
            ativo = data.get('ativo')

            if nome is None:
                nome = nome_armazenado
            if e_mail is None:
                e_mail = e_mail_armazenado
            if senha is None:
                senha = senha_armazenada
            if cnpj is None:
                cnpj = cnpj_armazenado
            if categoria is None:
                categoria = categoria_armazenada
            if descricao_da_causa is None:
                descricao_da_causa = descricao_armazenada
            if cep is None:
                cep = cep_armazenado
            if chave_pix is None:
                chave_pix = chave_pix_armazenado
            if num_agencia is None:
                num_agencia = num_agencia_armazenado
            if num_conta is None:
                num_conta = num_conta_armazenado
            if nome_banco is None:
                nome_banco = nome_banco_armazenado
            if endereco is None:
                endereco = endereco_armazenado
            if complemento is None:
                complemento = complemento_armazenado
            if nome_resp is None:
                nome_resp = nome_resp_armazenado
            if telefone is None:
                telefone = telefone_armazenado
            if site_url is None:
                site_url = site_url_armazenado
            if facebook is None:
                facebook = facebook_armazenado
            if instagram is None:
                instagram = instagram_armazenado
            if cidade is None:
                cidade = cidade_armazenada
            if tipo is None:
                tipo = tipo_usuario
            if ativo is None:
                ativo = atividade_armazenada

            cursor.execute("SELECT 1 FROM usuario WHERE E_MAIL = ?", (e_mail,))

            if e_mail_armazenado != e_mail:
                cursor.execute("SELECT 1 FROM usuario WHERE E_MAIL = ?", (e_mail,))
                if cursor.fetchone():
                    return jsonify({"error": "E-mail já cadastrado!"}), 400

            if senha_armazenada != senha:
                if not validar_senha(senha):
                    return jsonify({"error": 'A sua senha precisa ter pelo menos 8 caracteres, uma letra maiúscula, uma letra minúscula, um número e um caractere especial.'}), 401

                senha = generate_password_hash(senha).decode('utf-8')

            cursor.execute(
                "UPDATE usuario SET NOME = ?, E_MAIL = ?, SENHA = ?, CNPJ = ?, CATEGORIA = ?, DESCRICAO_DA_CAUSA = ?, CEP = ?, CHAVE_PIX = ?, NUM_AGENCIA = ?, NUM_CONTA = ?, NOME_BANCO = ?, ENDERECO = ?, COMPLEMENTO = ?, NOME_RESP = ?, TELEFONE = ?, SITE_URL = ?, FACEBOOK = ?, INSTAGRAM = ?, CIDADE = ?, TIPO = ?, ATIVO = ? WHERE ID_USUARIO = ?",
                (nome, e_mail, senha, cnpj, categoria, descricao_da_causa, cep, chave_pix, num_agencia, num_conta,
                 nome_banco, endereco, complemento, nome_resp, telefone, site_url, facebook, instagram, cidade, tipo, ativo,
                 id))
            con.commit()

            return jsonify({
                'message': "Cadastro atualizado com sucesso!",
                'usuario': {
                    'id_usuario': id,
                    'nome': nome,
                    'e_mail': e_mail,
                    'senha': senha,
                    'cnpj': cnpj,
                    'categoria': categoria,
                    'descricao_da_causa': descricao_da_causa,
                    'cep': cep,
                    'chave_pix': chave_pix,
                    'num_agencia': num_agencia,
                    'num_conta': num_conta,
                    'nome_banco': nome_banco,
                    'endereco': endereco,
                    'complemento': complemento,
                    'nome_resp': nome_resp,
                    'telefone': telefone,
                    'site_url': site_url,
                    'facebook': facebook,
                    'instagram': instagram,
                    'cidade': cidade,
                    'tipo': tipo,
                    'ativo': ativo
                }
            })
        return jsonify({
            'message': "Cadastro atualizado com sucesso!"})
    finally:
        if cursor:
            cursor.close()


@app.route('/cadastro', methods=['GET'])
def cadastro():
    cur = con.cursor()

    cur.execute(
        "SELECT id_usuario, nome, e_mail, senha, tipo, ativo, cnpj, categoria, descricao_da_causa, cep, chave_pix, num_agencia, num_conta, nome_banco, endereco, complemento, nome_resp, telefone, site_url, facebook, instagram, cidade FROM usuario")
    usuarios = cur.fetchall()
    cur.close()
    usuarios_dic = []

    for usuario in usuarios:
        id_usuario = usuario[0]
        nome = usuario[1]
        e_mail = usuario[2]
        senha = usuario[3]
        tipo = usuario[4]
        ativo = usuario[5]
        cnpj = usuario[6]
        categoria = usuario[7]
        descricao_da_causa = usuario[8]
        cep = usuario[9]
        chave_pix = usuario[10]
        num_agencia = usuario[11]
        num_conta = usuario[12]
        nome_banco = usuario[13]
        endereco = usuario[14]
        complemento = usuario[15]
        nome_resp = usuario[16]
        telefone = usuario[17]
        site_url = usuario[18]
        facebook = usuario[19]
        instagram = usuario[20]
        cidade = usuario[21]

        usuarios_dic.append({
            'id_usuario': id_usuario,
            'nome': nome,
            'e_mail': e_mail,
            'senha': senha,
            'tipo': tipo,
            'ativo': ativo,
            'cnpj': cnpj,
            'categoria': categoria,
            'descricao_da_causa': descricao_da_causa,
            'cep': cep,
            'chave_pix': chave_pix,
            'num_agencia': num_agencia,
            'num_conta': num_conta,
            'nome_banco': nome_banco,
            'endereco': endereco,
            'complemento': complemento,
            'nome_resp': nome_resp,
            'telefone': telefone,
            'site_url': site_url,
            'facebook': facebook,
            'instagram': instagram,
            'cidade': cidade
        })

    if usuarios_dic:
        return jsonify(mensagem='Registro de Cadastro de Usuários', usuarios=usuarios_dic)
    else:
        return jsonify(mensagem='Nenhum dado encontrado')


tentativas = 0
NOME = ''
ID = 0
EMAIL = ''


# LOGIN
@app.route('/login', methods=['POST'])
def login():
    cursor = con.cursor()
    try:
        data = request.get_json()

        e_mail = data.get('e_mail')
        senha = data.get('senha')

        global tentativas


        cursor.execute(
            "SELECT nome, e_mail, senha, tipo, id_usuario, ativo, cnpj, categoria, descricao_da_causa, cep, chave_pix, num_agencia, num_conta, nome_banco, endereco, complemento, nome_resp, telefone, site_url, facebook, instagram, cidade, aprovada FROM usuario WHERE e_mail = ?",
            (e_mail,))
        login_data = cursor.fetchone()
        print(0)

        # Verifique se login_data é None antes de acessar os dados
        if login_data is None:
            cursor.close()
            return jsonify({'error': "Credenciais não encontradas"}), 400

        print(1)
        # Se o usuário não estiver ativo
        if login_data[5] != 1:
            return jsonify({'message': "Usuário Inativo!"}), 400

        senha_hash = login_data[2]

        # Verifica se a senha está correta
        if check_password_hash(senha_hash, senha):
            token = generate_token(login_data[4], login_data[1])

            # Armazena dados na sessão

            tipo = login_data[3]

            if tipo == 1:
                url = "painel-admin.html"
            elif tipo == 2:
                url = "perfil_ong.html"

                if login_data[14] is None:
                    url = "home_apos_cadstro_ong.html"

            elif tipo == 3:
                url = "edicao-doador.html"

            # Retorna a resposta com o tipo de usuário
            return jsonify({
                'message': "Login feito com sucesso!",
                'tipo': login_data[3],
                'nome': login_data[0],
                'e_mail': login_data[1],
                'id_usuario': login_data[4],
                'cnpj': login_data[6],
                'categoria': login_data[7],
                'descricao_da_causa': login_data[8],
                'cep': login_data[9],
                'chave_pix': login_data[10],
                'num_agencia': login_data[11],
                'num_conta': login_data[12],
                'nome_banco': login_data[13],
                'endereco': login_data[14],
                'complemento': login_data[15],
                'nome_resp': login_data[16],
                'telefone': login_data[17],
                'site_url': login_data[18],
                'facebook': login_data[19],
                'instagram': login_data[20],
                'cidade': login_data[21],
                'aprovada': login_data[22],
                'token': token,
                'url': url
            }), 200

        if login_data[2] != 1:
            tentativas += 1
            print(tentativas)

            if tentativas == 3:
                cursor.execute("UPDATE usuario SET ativo = 0 WHERE id_usuario = ?", (login_data[4],))
                tentativas = 0
                con.commit()

                return jsonify({'error': "Usuário Inativo!"}), 400
        print(4)

        return jsonify({'error': "Senha incorreta!"}), 400
    finally:
        if cursor:
            cursor.close()


@app.route('/usuario/relatorio', methods=['GET'])
def usuario_relatorio():
    # CONSULTA COM BANCO
    cursor = None
    try:
        cursor = con.cursor()
        cursor.execute("SELECT id_usuario, nome, e_mail FROM usuario")
        usuarios = cursor.fetchall()
    finally:
        if cursor:
            cursor.close()

    # Cores
    azul_escuro = (8, 44, 91)  # #082C5B
    laranja = (243, 117, 0)  # #F37500

    # CRIAÇÃO DE PDF
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # Título
    pdf.set_text_color(*azul_escuro)
    pdf.set_font("Arial", style='B', size=18)
    pdf.cell(0, 10, "Relatório de Usuários", ln=True, align='C')
    pdf.ln(4)

    # Linha separadora
    pdf.set_draw_color(*laranja)
    pdf.set_line_width(1)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(8)

    # Cabeçalho de colunas
    pdf.set_fill_color(*laranja)
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("Arial", style='B', size=12)
    pdf.cell(30, 10, "ID Usuário", 1, 0, 'C', fill=True)
    pdf.cell(80, 10, "Nome", 1, 0, 'C', fill=True)
    pdf.cell(80, 10, "E-mail", 1, 1, 'C', fill=True)

    # Dados
    pdf.set_text_color(0, 0, 0)
    pdf.set_font("Arial", size=11)
    for usuario in usuarios:
        # Garantindo que os dados sejam strings
        id_usuario = str(usuario[0])
        nome = str(usuario[1])
        e_mail = str(usuario[2])

        # Preenchendo as células com os dados garantidos como strings
        pdf.cell(30, 10, id_usuario, 1, 0, 'C')
        pdf.cell(80, 10, nome, 1, 0, 'C')
        pdf.cell(80, 10, e_mail, 1, 1, 'C')

    # Total de usuários
    contador_usuarios = len(usuarios)
    pdf.ln(10)
    pdf.set_font("Arial", style='B', size=12)
    pdf.set_text_color(*azul_escuro)
    pdf.set_draw_color(*azul_escuro)
    pdf.set_fill_color(230, 230, 230)
    pdf.cell(0, 10, f"Total de usuários cadastrados: {contador_usuarios}", ln=True, align='C', fill=True, border=1)

    # SALVANDO E ENVIANDO O PDF
    pdf_path = "relatorio_usuarios.pdf"
    pdf.output(pdf_path)
    return send_file(pdf_path, as_attachment=True, mimetype='application/pdf')


@app.route('/doacao/doador/relatorio/<int:id>', methods=['GET'])
def doador_relatorio(id):
    id_usuario = id
    cursor = None
    try:
        cursor = con.cursor()
        cursor.execute("""
            SELECT d.id_usuario, d.id_ong, doa.NOME, d.data_doacao, d.valor, ong.nome 
            FROM doacoes D 
            LEFT JOIN USUARIO doa  ON doa.ID_USUARIO  = d.ID_USUARIO 
            LEFT JOIN USUARIO ong ON ong.id_usuario = d.ID_ONG 
            WHERE d.id_usuario = ?
        """, (id_usuario,))
        doacao = cursor.fetchall()
    finally:
        if cursor:
            cursor.close()

    # Cores
    azul_escuro = (8, 44, 91)  # #082C5B
    laranja = (243, 117, 0)  # #F37500

    # Criação do PDF
    pdf = FPDF(orientation='L')
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # Título
    pdf.set_text_color(*azul_escuro)
    pdf.set_font("Arial", style='B', size=18)
    pdf.cell(0, 10, "Relatório de Doações do Doador", ln=True, align='C')
    pdf.ln(4)

    # Linha separadora
    pdf.set_draw_color(*laranja)
    pdf.set_line_width(1)
    pdf.line(10, pdf.get_y(), 280, pdf.get_y())
    pdf.ln(8)

    # Cabeçalho de colunas
    pdf.set_fill_color(*laranja)
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("Arial", style='B', size=12)

    tabela_largura = 200
    pagina_largura_util = 277  # largura total - margens
    margem_esquerda = (pagina_largura_util - tabela_largura) / 2
    pdf.set_x(margem_esquerda)

    pdf.cell(60, 10, "Nome da ONG", 1, 0, 'C', fill=True)
    pdf.cell(60, 10, "Nome do Doador", 1, 0, 'C', fill=True)
    pdf.cell(30, 10, "Valor", 1, 0, 'C', fill=True)
    pdf.cell(40, 10, "Data", 1, 1, 'C', fill=True)

    # Dados
    pdf.set_text_color(0, 0, 0)
    pdf.set_font("Arial", size=11)
    for d in doacao:
        # Verifica se a data já é um objeto datetime
        if isinstance(d[3], datetime):
            # Se for datetime, converte para o formato desejado
            data_formatada = d[3].strftime('%d/%m/%Y')
        else:
            # Se for string, converte para datetime e então para o formato desejado
            try:
                data_formatada = datetime.strptime(str(d[3]), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y')
            except ValueError:
                # Caso a data não esteja no formato esperado, usa o valor original
                data_formatada = str(d[3])

        pdf.set_x(margem_esquerda)

        pdf.cell(60, 10, str(d[5]) if d[5] is not None else '', 1, 0, 'C')
        pdf.cell(60, 10, d[2], 1, 0, 'C')
        pdf.cell(30, 10, f"R$ {d[4]:.2f}", 1, 0, 'C')
        pdf.cell(40, 10, data_formatada, 1, 1, 'C')

    # Total de doações
    pdf.ln(10)
    pdf.set_font("Arial", style='B', size=12)
    pdf.set_text_color(*azul_escuro)
    pdf.set_draw_color(*azul_escuro)
    pdf.set_fill_color(230, 230, 230)
    pdf.cell(0, 10, f"Total de doações realizadas: {len(doacao)}", ln=True, align='C', fill=True, border=1)

    # Gerar PDF
    pdf_path = "relatorio_doacoes_doador.pdf"
    pdf.output(pdf_path)
    return send_file(pdf_path, as_attachment=True, mimetype='application/pdf')


@app.route('/doacao/ong/relatorio/<int:id>', methods=['GET'])
def ong_relatorio(id):
    # CONSULTA COM BANCO
    id_ong = id
    cursor = None
    try:
        cursor = con.cursor()
        cursor.execute("""
            SELECT d.id_usuario, d.id_ong, doa.NOME, d.data_doacao, d.valor, ong.nome 
            FROM doacoes D 
            LEFT JOIN USUARIO doa ON doa.ID_USUARIO = d.ID_USUARIO 
            LEFT JOIN USUARIO ong ON ong.id_usuario = d.ID_ONG 
            WHERE id_ong = ?
        """, (id_ong,))
        doacao = cursor.fetchall()
    finally:
        if cursor:
            cursor.close()

    # Cores
    azul_escuro = (8, 44, 91)  # #082C5B
    laranja = (243, 117, 0)  # #F37500

    # CRIAÇÃO DE PDF
    pdf = FPDF(orientation='L')  # Modo paisagem
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # Título
    pdf.set_text_color(*azul_escuro)
    pdf.set_font("Arial", style='B', size=18)
    pdf.cell(0, 10, "Relatório de Doações da ONG", ln=True, align='C')
    pdf.ln(4)

    # Linha separadora
    pdf.set_draw_color(*laranja)
    pdf.set_line_width(1)
    pdf.line(10, pdf.get_y(), 280, pdf.get_y())
    pdf.ln(8)

    # Cabeçalho de colunas
    pdf.set_fill_color(*laranja)
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("Arial", style='B', size=12)

    tabela_largura = 200
    pagina_largura_util = 277  # largura total - margens
    margem_esquerda = (pagina_largura_util - tabela_largura) / 2
    pdf.set_x(margem_esquerda)

    pdf.cell(55, 10, "Nome da ONG", 1, 0, 'C', fill=True)
    pdf.cell(55, 10, "Nome do Doador", 1, 0, 'C', fill=True)
    pdf.cell(50, 10, "Valor", 1, 0, 'C', fill=True)
    pdf.cell(40, 10, "Data", 1, 1, 'C', fill=True)

    # Dados
    pdf.set_text_color(0, 0, 0)
    pdf.set_font("Arial", size=11)
    for d in doacao:
        # Converte para formato brasileiro e remove a hora
        if isinstance(d[3], datetime):
            data_formatada = d[3].strftime('%d/%m/%Y')
        else:
            try:
                data_formatada = datetime.strptime(str(d[3]), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y')
            except ValueError:
                data_formatada = str(d[3])

        pdf.set_x(margem_esquerda)

        pdf.cell(55, 10, str(d[5]) if d[5] is not None else '', 1, 0, 'C')
        pdf.cell(55, 10, d[2], 1, 0, 'C')
        pdf.cell(50, 10, f"R$ {d[4]:.2f}", 1, 0, 'C')  # Aumentado de 30 para 50
        pdf.cell(40, 10, data_formatada, 1, 1, 'C')


    # Total de doações
    contador_doacoes = len(doacao)
    pdf.ln(10)
    pdf.set_font("Arial", style='B', size=12)
    pdf.set_text_color(*azul_escuro)
    pdf.set_draw_color(*azul_escuro)
    pdf.set_fill_color(230, 230, 230)
    pdf.cell(0, 10, f"Total de doações recebidas: {contador_doacoes}", ln=True, align='C', fill=True, border=1)

    # Gerar PDF
    pdf_path = "relatorio_doacoes_ong.pdf"
    pdf.output(pdf_path)
    return send_file(pdf_path, as_attachment=True, mimetype='application/pdf')



@app.route('/imagem/<int:id>', methods=['PUT', 'OPTIONS'])
def imagem(id):
    imagem = request.files.get('imagem')  # Arquivo enviado

    cursor = con.cursor()
    try:
        # Verifica se já existe
        cursor.execute("SELECT 1 FROM usuario WHERE id_usuario = ?", (id,))
        if not cursor.fetchone():
            return jsonify({"error": "Usuário não encontrado"}), 400

        # Salvando a imagem se for enviada
        imagem_path = None
        if imagem:
            nome_imagem = f"{id}.jpeg"  # Define o nome fixo com .jpeg
            pasta_destino = os.path.join(app.config['UPLOAD_FOLDER'], "Livros")
            os.makedirs(pasta_destino, exist_ok=True)
            imagem_path = os.path.join(pasta_destino, nome_imagem)
            imagem.save(imagem_path)

        # VERIFICA SE A IMAGEM FOI SALVA
        return jsonify({
            'message': "Usuário cadastrado com sucesso!",
            'usuario': {
                'id': id,
                'imagem_path': imagem_path,
            }
        }), 201
    finally:
        if cursor:
            cursor.close()


@app.route('/logout', methods=['POST'])
def logout():
    response = jsonify({'message': 'Logout realizado com sucesso'})  # Exibe a mensagem de logout realizado com sucesso
    response.delete_cookie('token')  # Deleta token (cookie) temporário exbido durante o login
    return response  # Retorna resposta


# função para calcular o crc16 do payload, ou seja, verifica a integridade dos dados com base no conteúdo útil da mensagem, que seria o payload
def calcula_crc16(payload):
    crc16 = crcmod.mkCrcFun(0x11021, initCrc=0xFFFF, rev=False)
    crc = crc16(payload.encode('utf-8'))
    return f"{crc:04X}"


# função para formatar os campos no padrão tlv (tag, length, value), ou seja, o tipo do dado, o comprimento do valor e o conteúdo real do dado
def format_tlv(id, value):
    return f"{id}{len(value):02d}{value}"


# rota da api flask para gerar um código pix
@app.route('/gerar_pix/<int:id_ong>', methods=['POST'])
def gerar_pix(id_ong):
    try:
        # obtém os dados do json enviado na requisição
        data = request.get_json()

        # valida se o valor foi enviado
        if not data or 'valor' not in data:
            return jsonify({"erro": "O valor do PIX é obrigatório."}), 400

        # obtém e formata os dados necessários (2f = 2 casas decimais)
        valor = f"{float(data['valor']):.2f}"
        email = data['e_mail']
        id_usuario = data['id']
        nome = data['nome']
        data_doacao = datetime.now()

        # consulta os dados da ong (chave pix, nome e cidade)
        cursor = con.cursor()
        cursor.execute("SELECT CHAVE_PIX, NOME_RESP, CIDADE FROM USUARIO WHERE ID_USUARIO = ?", (id_ong,))
        resultado = cursor.fetchone()
        cursor.close()

        # valida se encontrou a ong
        if not resultado:
            return jsonify({"erro": f"Chave PIX não encontrada para o ID {id_ong}"}), 404

        # extrai os dados retornados e limita o tamanho dos campos
        chave_pix, nome_resp, cidade = resultado
        nome_resp = nome_resp[:25] if nome_resp else "Recebedor PIX"
        cidade = cidade[:15] if cidade else "Cidade"

        # registra a doação no banco de dados
        cur = con.cursor()
        cur.execute("INSERT INTO DOACOES(ID_USUARIO, ID_ONG, VALOR, DATA_DOACAO) VALUES (?, ?, ?, ?)",
                    (id_usuario, id_ong, valor, data_doacao))
        con.commit()
        cur.close()

        # monta o campo com informações do recebedor (tlv)
        merchant_account_info = (
                format_tlv("00", "br.gov.bcb.pix") +
                format_tlv("01", chave_pix)
        )
        campo_26 = format_tlv("26", merchant_account_info)

        # monta o payload do pix sem o crc (algoritmo que gera o código de 16 bites a partir do payload) ainda
        payload_sem_crc = (
                "000201" +
                "010212" +
                campo_26 +
                "52040000" +
                "5303986" +
                format_tlv("54", valor) +
                "5802BR" +
                format_tlv("59", nome_resp) +
                format_tlv("60", cidade) +
                format_tlv("62", format_tlv("05", "***")) +
                "6304"
        )

        # calcula o crc16 e adiciona ao final do payload
        crc = calcula_crc16(payload_sem_crc)
        payload_completo = payload_sem_crc + crc

        # gera o qr code com base no payload
        qr = qrcode.make(payload_completo)

        # define o caminho onde a imagem será salva
        pasta_uploads = os.path.join("static/uploads", "qrcode")
        os.makedirs(pasta_uploads, exist_ok=True)

        nome_arquivo = f"pix_{id_ong}.png"
        caminho_arquivo = os.path.join(pasta_uploads, nome_arquivo)

        # salva a imagem do qr code
        qr.save(caminho_arquivo)

        # formata a data atual para exibir no e-mail
        data_atual = datetime.now().strftime('%d/%m/%Y %H:%M')

        # monta o corpo do e-mail em html
        html_corpo = f"""
         <html>
        <head>
            <style>
                body {{
                    font-family: Poppins;
                    color: #000000;
                    background-color: #898989;
                    margin: 0;
                    padding: 0;
                }}
                .container {{
                    width: 100%;
                    max-width: 600px;
                    margin: 20px auto;
                    padding: 20px;
                    background-color: #ffffff;
                    border-radius: 8px;
                    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                }}
                h2 {{
                    color: #082C5B;
                    font-size: 24px;
                    text-align: center;
                    margin-bottom: 20px;
                }}
                p {{
                    font-size: 16px;
                    line-height: 1.6;
                }}
                .highlight {{
                    font-weight: bold;
                    color: #F37500;
                }}
                .footer {{
                    text-align: center;
                    margin-top: 30px;
                    font-size: 14px;
                    color: #777777;
                }}
                .btn {{
                    display: inline-block;
                    border-radius: 8px;
                    font-style: #ffffff;
                    padding: 10px 20px;
                    font-size: 16px;
                    text-decoration: none;
                    border-radius: 6px;
                    text-align: center;
                    margin-top: 20px;
                    display: inline-block;
                    background-image: linear-gradient(to right, #082C5B, #F37500);
                    transition: background-color 0.3s;
                }}
                .qr-code {{
                    display: block;
                    margin: 20px auto;
                    border: 2px solid #f1f1f1;
                    padding: 10px;
                    border-radius: 9px;
                    background-color: #fafafa;
                }}
                .white {{
                    color: #ffffff;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h2>💵 Confirmação de PIX para {nome_resp}</h2>
                <p>Olá, <span class="highlight">{nome}</span>!</p>
                <p>Estamos muito felizes em contar com seu apoio e expressamos nossa gratidão!</p>
                <p>Sua doação para a ONG <strong>{nome_resp}</strong>, localizada em <strong>{cidade}</strong>, é de extrema importância para a continuidade do seu trabalho social.</p>
                <p>O valor doado foi de <span class="highlight">R$ {valor}</span>, e a doação foi realizada no dia <span class="highlight">{data_atual}</span>.</p>

                <center>
                    <a href="#" class="btn"><span class="white">Obrigada por fazer a diferença!</span></a>
                    <div>
                        <img width="200px" src="cid:cartazfilme" alt="QR Code PIX" />
                    </div>
                </center>

                <div class="footer">
                    <p>Atenciosamente,</p>
                    <p><strong>Equipe Doe Aí</strong></p>
                    <p>www.doeai.com</p>
                </div>
            </div>
            <div class="qr-code">
                <img center width="850px" src="https://i.imgur.com/0U4j1Mx.png" alt="QR Code PIX" />
            </div>
        </body>
        </html>
        """

        # envia o e-mail com o html e imagem do qr code
        enviar_email(email, html_corpo, caminho_arquivo)

        # retorna o nome do arquivo do qr code
        return jsonify({
            "qrcode": nome_arquivo
        })

    # captura e retorna erros internos
    except Exception as e:
        return jsonify({"erro": f"Ocorreu um erro interno: {str(e)}"}), 500


# função responsável por enviar o e-mail com o qr code
def enviar_email(email, html_corpo, caminho_img):
    if not email:
        raise ValueError("Endereço de e-mail não fornecido.")

    # define remetente, assunto e credenciais
    subject = "💵 Confirmação de Doação - Doe Aí"
    sender = "doeaiongs@gmail.com"
    recipients = [email]
    password = "lukn atsm wilw abpt"  # senha de app do gmail

    try:
        # cria o e-mail multipart com html + imagem
        msg_root = MIMEMultipart('related')
        msg_root['Subject'] = subject
        msg_root['From'] = sender
        msg_root['To'] = ', '.join(recipients)

        # adiciona conteúdo alternativo (html)
        msg_alternativo = MIMEMultipart('alternative')
        msg_root.attach(msg_alternativo)

        # insere o corpo html
        msg_alternativo.attach(MIMEText(html_corpo, 'html', 'utf-8'))

        # anexa a imagem do qr code como inline (ou seja, sem a necessidade de links externos)
        with open(caminho_img, 'rb') as img_file:
            imagem = MIMEImage(img_file.read())
            imagem.add_header('Content-ID', '<cartazfilme>')
            imagem.add_header('Content-Disposition', 'inline', filename='cartaz.jpg')
            msg_root.attach(imagem)

        # envia o e-mail usando smtp (protocolo utilizado para enviar email entre servidores) com ssl (protocolo que criptografa a comunicação) - segurança
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp_server:
            smtp_server.login(sender, password)
            smtp_server.sendmail(sender, recipients, msg_root.as_string())

        # exibe confirmação
        print("E-mail enviado com sucesso!")

    except Exception as e:
        # exibe erro
        print(f" Ocorreu um erro ao enviar o e-mail: {e}")

# @app.route('/aprovada/<int:id_usuario>', methods=['PUT'])
# def aprovar_ong(id_usuario):
#     try:
#         data = request.get_json()
#         aprovada = data.get('aprovada')
#
#         cur = con.cursor()
#         cur.execute("UPDATE USUARIO SET APROVADA = ? WHERE ID_USUARIO = ?", (aprovada, id_usuario))
#         con.commit()
#
#         # Buscar informações da ONG para o e-mail
#         cur.execute("SELECT NOME_RESP, E_MAIL FROM USUARIO WHERE ID_USUARIO = ?", (id_usuario,))
#         result = cur.fetchone()
#         cur.close()
#
#         if not result:
#             return jsonify({"error": "ONG não encontrada."}), 404
#
#         nome_resp, email = result
#         data_atual = datetime.now().strftime('%d/%m/%Y %H:%M')
#
#         html = f"""
#         <html>
#         <style>
#             .footer {{
#                 text-align: center;
#                 margin-top: 30px;
#                 font-size: 14px;
#                 color: #777777;
#             }}
#         </style>
#         <body style="font-family: Poppins; padding: 20px;">
#             <h2 style="color: #082C5B;">🎉 Parabéns, {nome_resp}!</h2>
#             <p>Sua ONG foi <strong>aprovada</strong> com sucesso na plataforma Doe Aí em <strong>{data_atual}</strong>.</p>
#             <p>A partir de agora, você poderá receber doações e participar ativamente da nossa rede.</p>
#             <p>Qualquer dúvida, estamos à disposição.</p>
#             <div class="footer">
#                 <p>Atenciosamente,</p>
#                 <p><strong>Equipe Doe Aí</strong></p>
#                 <p>www.doeai.com</p>
#             </div>
#         </body>
#         </html>
#         """
#
#         enviar_email(email, html)
#         return jsonify({"message": "ONG aprovada com sucesso.", "aprovada": aprovada})
#
#     except Exception as e:
#         return jsonify({"error": f"Erro ao aprovar ONG: {str(e)}"}), 500

def enviar_emailll(email, html_corpo):
    if not email:
        raise ValueError("Endereço de e-mail não fornecido.")

    # define remetente, assunto e credenciais
    subject = "✅ Notificação de ONG aprovada"
    sender = "doeaiongs@gmail.com"
    recipients = [email]
    password = "lukn atsm wilw abpt"

    try:
        # cria o e-mail multipart com html + imagem
        msg_root = MIMEMultipart('related')
        msg_root['Subject'] = subject
        msg_root['From'] = sender
        msg_root['To'] = ', '.join(recipients)

        # adiciona conteúdo alternativo (html)
        msg_alternativo = MIMEMultipart('alternative')
        msg_root.attach(msg_alternativo)

        # insere o corpo html
        msg_alternativo.attach(MIMEText(html_corpo, 'html', 'utf-8'))

        # envia o e-mail usando smtp (protocolo utilizado para enviar email entre servidores) com ssl (protocolo que criptografa a comunicação) - segurança
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp_server:
            smtp_server.login(sender, password)
            smtp_server.sendmail(sender, recipients, msg_root.as_string())

        print("E-mail enviado com sucesso!")

    except Exception as e:
        # exibe erro
        print(f" Ocorreu um erro ao enviar o e-mail: {e}")

@app.route('/aprovada/<int:id_usuario>', methods=['PUT'])
def aprovar_ong(id_usuario):
    cur = None
    try:
        cur = con.cursor()
        cur.execute("SELECT NOME_RESP, NOME, E_MAIL FROM USUARIO WHERE ID_USUARIO = ?", (id_usuario,))
        result = cur.fetchone()

        if not result:
            return jsonify({"error": "ONG não encontrada."}), 404

        nome_resp, nome, email = result

        cur.execute("UPDATE USUARIO SET APROVADA = 1, ATIVO = 1 WHERE ID_USUARIO = ?", (id_usuario,))
        con.commit()

        html_corpo = f"""
         <html>
        <head>
            <style>
                body {{
                    font-family: Poppins;
                    color: #000000;
                    background-color: #898989;
                    margin: 0;
                    padding: 0;
                }}
                .container {{
                    width: 100%;
                    max-width: 600px;
                    margin: 20px auto;
                    padding: 20px;
                    background-color: #e6e8eb;
                    border-radius: 8px;
                    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                }}
                h2 {{
                    color: #082C5B;
                    font-size: 24px;
                    text-align: center;
                    margin-bottom: 20px;
                }}
                p {{
                    font-size: 16px;
                    line-height: 1.6;
                    color: #082C5B;
                    text-decoration: none;
                }}
                .highlight {{
                    font-weight: bold;
                    color: #F37500;
                }}
                .footer {{
                    text-align: center;
                    margin-top: 30px;
                    font-size: 14px;
                    color: #777777;
                }}
                .btn {{
                    display: inline-block;
                    border-radius: 8px;
                    font-style: #ffffff;
                    padding: 10px 20px;
                    font-size: 16px;
                    text-decoration: none;
                    border-radius: 6px;
                    text-align: center;
                    margin-top: 20px;
                    display: inline-block;
                    background-image: linear-gradient(to right, #082C5B, #F37500);
                    transition: background-color 0.3s;
                }}
                .white {{
                    color: #ffffff;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h2>Sua ONG foi aprovada!</h2>
                <p>🎉 Parabéns, <span class="highlight">{nome_resp}</span>!</p>
                <p>É com alegria que informamos que sua ONG <strong>{nome}</strong> foi aprovada com sucesso em nossa plataforma Doe Aí hoje!</p>
                <p>A partir de agora, você poderá receber doações, ser visualizada e ter controle sobre o apoio que receber por meio da participação ativa em nossa rede, uma vez que seus dados se encontraram dentro padrão do estabelecido por nossa administração.</p>
                <p>A equipe Doe Aí está a sua disposição para possíveis dúvidas e agradecemos pela confiança!</p>

                <center>
                    <a href="#" class="btn"><span class="white">Obrigada por escolher mudar o mundo ao nosso lado!</span></a>
                <center>
                
                <div class="footer">
                    <p>Atenciosamente,</p>
                    <p><strong>Equipe Doe Aí</strong></p>
                    <p>www.doeai.com</p>
                </div>
            </div>
        </body>
        </html>
        """

        enviar_emailll(email, html_corpo)
        return jsonify({"message": "ONG aprovada com sucesso."}), 200

    except Exception as e:
        return jsonify({"message": f"Ocorreu um erro ao aprovar a ONG: {str(e)}"}), 400

    finally:
        if cur is not None and not cur.close():
            try:
                cur.close()
            except Exception:
                pass

def enviar_emaill(email, html_corpo):
    if not email:
        raise ValueError("Endereço de e-mail não fornecido.")

    # define remetente, assunto e credenciais
    subject = "😔 Aviso de ONG não credenciada"
    sender = "doeaiongs@gmail.com"
    recipients = [email]
    password = "lukn atsm wilw abpt"

    try:
        # cria o e-mail multipart com html + imagem
        msg_root = MIMEMultipart('related')
        msg_root['Subject'] = subject
        msg_root['From'] = sender
        msg_root['To'] = ', '.join(recipients)

        # adiciona conteúdo alternativo (html)
        msg_alternativo = MIMEMultipart('alternative')
        msg_root.attach(msg_alternativo)

        # insere o corpo html
        msg_alternativo.attach(MIMEText(html_corpo, 'html', 'utf-8'))

        # envia o e-mail usando smtp (protocolo utilizado para enviar email entre servidores) com ssl (protocolo que criptografa a comunicação) - segurança
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp_server:
            smtp_server.login(sender, password)
            smtp_server.sendmail(sender, recipients, msg_root.as_string())

        print("E-mail enviado com sucesso!")

    except Exception as e:
        # exibe erro
        print(f" Ocorreu um erro ao enviar o e-mail: {e}")


@app.route('/naoaprovada/<int:id_usuario>', methods=['PUT'])
def excluir_ong(id_usuario):
    cur = None
    try:
        cur = con.cursor()
        cur.execute("SELECT NOME_RESP, NOME, E_MAIL FROM USUARIO WHERE ID_USUARIO = ?", (id_usuario,))
        result = cur.fetchone()

        if not result:
            return jsonify({"error": "ONG não encontrada."}), 404

        nome_resp, nome, email = result

        cur.execute("UPDATE USUARIO SET APROVADA = 0, ATIVO = 0 WHERE ID_USUARIO = ?", (id_usuario,))
        con.commit()

        html_corpo = f"""
         <html>
        <head>
            <style>
                body {{
                    font-family: Poppins;
                    color: #000000;
                    background-color: #898989;
                    margin: 0;
                    padding: 0;
                }}
                .container {{
                    width: 100%;
                    max-width: 600px;
                    margin: 20px auto;
                    padding: 20px;
                    background-color: #e6e8eb;
                    border-radius: 8px;
                    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                }}
                h2 {{
                    color: #082C5B;
                    font-size: 24px;
                    text-align: center;
                    margin-bottom: 20px;
                }}
                p {{
                    font-size: 16px;
                    line-height: 1.6;
                    color: #082C5B;
                    text-decoration: none;
                }}
                .highlight {{
                    font-weight: bold;
                    color: #F37500;
                }}
                .footer {{
                    text-align: center;
                    margin-top: 30px;
                    font-size: 14px;
                    color: #777777;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h2>😔 Sua ONG foi excluída</h2>
                <p>Olá, <span class="highlight">{nome_resp}</span>,</p>
                <p>Informamos que sua ONG (que corresponde ao nome de <strong>{nome}</strong>) foi removida de nossa plataforma Doe Aí ao passar por nossa curadoria no processo de aprovação, pois infelizmente não se encontrava nos parâmetros da Fundação.</p>
                <p>Para voltar a participar, ter a oportunidade de receber doações e ser visualizada em nosso sistema, será necessário realizar um novo cadastro que será aprovado quando dentro do estabelecido por nossa administração.</p>
                <p>Desde já agradecemos pela compreensão e por toda confiança em nosso processo de triagem, desejamos sucesso e <strong>nos vemos em breve!<strong></p>

                <div class="footer">
                    <p>Atenciosamente,</p>
                    <p><strong>Equipe Doe Aí</strong></p>
                    <p>www.doeai.com</p>
                </div>
            </div>
        </body>
        </html>
        """

        enviar_emaill(email, html_corpo)
        return jsonify({"message": "ONG excluída com sucesso."}), 200

    except Exception as e:
        return jsonify({"message": f"Ocorreu um erro ao excluir a ONG: {str(e)}"}), 400

    finally:
        if cur is not None and not cur.close():
            try:
                cur.close()
            except Exception:
                pass
@app.route('/doacoes_quant/<int:id_ong>', methods=['GET'])
def doacoes_len(id_ong):
    try:
        cur = con.cursor()

        cur.execute(
            "SELECT valor FROM doacoes WHERE id_ong = ?", (id_ong,))
        doacao = cur.fetchall()

        contador_doacao = len(doacao)

        return jsonify({
            'message': str(contador_doacao)
        })

    finally:
        if cur:
            cur.close()

@app.route('/doacoes/<int:id_ong>', methods=['GET'])
def doacoes_sum(id_ong):
    cur = con.cursor()

    # Faz a soma direto no SQL
    cur.execute("SELECT SUM(valor) FROM doacoes WHERE id_ong = ?", (id_ong,))
    resultado = cur.fetchone()

    # Se não houver doações, o resultado será None
    soma_doacao = resultado[0] if resultado[0] is not None else 0

    # Formata com separador de milhar (ponto)
    soma_formatada = format(soma_doacao, ',').replace(',', '.')

    cur.close()

    return jsonify({
        'message': soma_formatada
    })


@app.route('/doacoes_quant_doador/<int:id_usuario>', methods=['GET'])
def doacoes_len_doador(id_usuario):
    cur = con.cursor()
    try:
        cur.execute(
            "SELECT valor FROM doacoes WHERE id_usuario = ?", (id_usuario,))
        doacao = cur.fetchall()

        contador_doacao = len(doacao)

        return jsonify({
            'message': str(contador_doacao)
        })
    finally:
        if cur:
            cur.close()


@app.route('/doacoes_doador/<int:id_usuario>', methods=['GET'])
def doacoes_sum_doador(id_usuario):
    cur = con.cursor()

    # Faz a soma direto no SQL
    cur.execute("SELECT SUM(valor) FROM doacoes WHERE id_usuario = ?", (id_usuario,))
    resultado = cur.fetchone()

    # Se não houver doações, o resultado será None
    soma_doacao = resultado[0] if resultado[0] is not None else 0

    # Formata com separador de milhar (ponto)
    soma_formatada = format(soma_doacao, ',').replace(',', '.')

    cur.close()

    return jsonify({
        'message': soma_formatada
    })


@app.route('/doacoes_quant_admin', methods=['GET'])
def doacoes_len_admin():
    id_usuario = request.args.get('id_usuario')
    id_ong = request.args.get('id_ong')

    if not id_usuario or not id_ong:
        return jsonify({'error': 'Parâmetros id_usuario e id_ong são obrigatórios'}), 400

    cur = con.cursor()
    cur.execute(
        "SELECT valor FROM doacoes WHERE id_usuario = ? AND id_ong = ?", (id_usuario, id_ong,))
    doacao = cur.fetchall()
    cur.close()
    contador_doacao = len(doacao)

    return jsonify({
        'message': str(contador_doacao)
    })


@app.route('/doacoes_admin', methods=['GET'])
def doacoes_sum_admin():
    cur = con.cursor()

    # Faz a soma direto no SQL
    cur.execute("SELECT SUM(valor) FROM doacoes")
    resultado = cur.fetchone()
    cur.close()

    # Se não houver doações, o resultado será None
    soma_doacao = resultado[0] if resultado[0] is not None else 0

    # Formata com separador de milhar (ponto)
    soma_formatada = format(soma_doacao, ',').replace(',', '.')

    return jsonify({
        'message': soma_formatada
    })

@app.route('/usuario/total', methods=['GET'])
def usuario_total():
    cursor = con.cursor()
    cursor.execute("SELECT id_usuario FROM usuario")
    usuarios = cursor.fetchall()

    total_usuarios = len(usuarios)

    cursor.close()
    return jsonify({'total_usuarios': total_usuarios})

@app.route('/ongs/total', methods=['GET'])
def ongs_total():
    cursor = con.cursor()
    cursor.execute("SELECT id_usuario FROM usuario WHERE tipo = 2")
    ongs = cursor.fetchall()

    total_ongs = len(ongs)

    cursor.close()

    return jsonify({'message': total_ongs})



@app.route('/doacao_historico/<int:id_ong>', methods=['GET'])
def doacao_historico(id_ong):
    # CONSULTA COM BANCO
    cursor = None
    try:
        cursor = con.cursor()
        cursor.execute("""
            SELECT d.data_doacao, d.valor, doa.NOME
            FROM doacoes D 
            LEFT JOIN USUARIO doa ON doa.ID_USUARIO = d.ID_USUARIO 
            LEFT JOIN USUARIO ong ON ong.id_usuario = d.ID_ONG 
            WHERE d.id_ong = ?
        """, (id_ong,))
        doacao = cursor.fetchall()
    finally:
        if cursor:
            cursor.close()
    resultado = []
    for d in doacao:
        data_sem_formatacao = d[0]  # data_doacao
        if isinstance(data_sem_formatacao, datetime):
            data_formatada = data_sem_formatacao.strftime('%d/%m/%Y')
        else:
            try:
                data_formatada = datetime.strptime(str(data_sem_formatacao), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y')
            except ValueError:
                data_formatada = str(data_sem_formatacao)
        resultado.append({
            'data_doacao': data_formatada,
            'valor': float(d[1]),
            'nome_doador': (d[2])
        })
    return jsonify(resultado)


@app.route('/doacao_historico_doador/<int:id_usuario>', methods=['GET'])
def doacao_historico_doador(id_usuario):
    # CONSULTA COM BANCO
    cursor = None
    try:
        cursor = con.cursor()
        cursor.execute("""
            SELECT d.data_doacao, d.valor, ong.NOME, d.id_ong
            FROM doacoes D 
            LEFT JOIN USUARIO doa ON doa.ID_USUARIO = d.ID_USUARIO 
            LEFT JOIN USUARIO ong ON ong.id_usuario = d.ID_ONG 
            WHERE d.id_usuario = ?
        """, (id_usuario,))
        doacao = cursor.fetchall()
    finally:
        if cursor:
            cursor.close()
    resultado = []
    for d in doacao:
        data_sem_formatacao = d[0]  # data_doacao
        if isinstance(data_sem_formatacao, datetime):
            data_formatada = data_sem_formatacao.strftime('%d/%m/%Y')
        else:
            try:
                data_formatada = datetime.strptime(str(data_sem_formatacao), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y')
            except ValueError:
                data_formatada = str(data_sem_formatacao)
        resultado.append({
            'data_doacao': data_formatada,
            'valor': float(d[1]),
            'nome_ong': (d[2]),
            'id_ong': d[3]
        })
    return jsonify(resultado)

@app.route('/static/uploads/Livros/<filename>')
def send_logo(filename):
    return send_from_directory('static/uploads/Livros', filename)


@app.route('/feed_doador/<int:id_usuario>', methods=['GET'])
def feed_doador(id_usuario):
    cursor = con.cursor()
    try:
        cursor.execute("""SELECT DISTINCT d.id_ong 
                        FROM doacoes d
                        WHERE id_usuario = ?""",(id_usuario,))

        ongs_doadas = cursor.fetchall()

        print(f"ongs que doei {ongs_doadas}")

        if not ongs_doadas:
            return jsonify(mensagem="Você ainda não doou para nenhuma ONG.")

        id_ongs = [str(ong[0]) for ong in ongs_doadas]
        ids_formatados = ",".join(id_ongs)
        print(f"ids das ongs {id_ongs}")
        print(f"ids formatados {ids_formatados}")

        cursor.execute(f"""
                SELECT p.id_projeto, p.descricao, p.data_projeto, p.id_usuario, u.nome 
                FROM projeto p
                LEFT JOIN usuario u ON p.id_usuario = u.id_usuario
                WHERE p.id_usuario IN({ids_formatados})
                ORDER BY p.data_projeto DESC
            """)
        projetos = cursor.fetchall()

        print(projetos)

        projetos_dic = []

        for projeto in projetos:
            id_projeto = projeto[0]
            descricao = projeto[1]
            data_projeto = projeto[2]
            id_usuario = projeto[3]
            nome = projeto[4]

            if isinstance(data_projeto,
                          str):  # Isinstance serve para verificar se um objeto é de um tipo específico (ou de uma tupla de tipos)
                try:
                    data_projeto = datetime.strptime(data_projeto, "%d/%m/%Y %H:%M")
                except:
                    try:
                        data_projeto = datetime.fromisoformat(
                            data_projeto)  # fromisoformat: Converte uma String do formato ISO 8601 em um objeto datetime ou date
                    except:
                        data_projeto = datetime.now()

            locale.setlocale(locale.LC_TIME, 'pt_BR.UTF-8')
            if data_projeto is not None:
                # Formatar a data com o mês por extenso e hora
                data_formatada = f"Publicado em {data_projeto.day} de {data_projeto.strftime('%B')} de {data_projeto.year} às {data_projeto.strftime('%H:%M')}"
            else:
                data_formatada = "Data não disponível"

            # Adicionando o projeto à lista
            projetos_dic.append({
                'id_projeto': id_projeto,
                'data_projeto': data_formatada,
                'descricao': descricao,
                'id_usuario': id_usuario,
                'nome': nome
            })

        return jsonify(mensagem='Feed com projetos da ONGs que você apoiou.', projetos=projetos_dic)
    finally:
        if cursor:
            cursor.close()

@app.route('/doacao_historico_geral/', methods=['GET'])
def doacao_historico_geral():
    cursor = None
    try:
        cursor = con.cursor()
        cursor.execute("""
            SELECT d.data_doacao, d.valor, ong.NOME, doa.nome
            FROM doacoes d
            LEFT JOIN USUARIO doa ON doa.ID_USUARIO = d.ID_USUARIO 
            LEFT JOIN USUARIO ong ON ong.ID_USUARIO = d.ID_ONG 
        """)
        doacoes = cursor.fetchall()
    finally:
        if cursor:
            cursor.close()

    resultado = []
    for d in doacoes:
        data_sem_formatacao = d[0]
        if isinstance(data_sem_formatacao, datetime):
            data_formatada = data_sem_formatacao.strftime('%d/%m/%Y')
        else:
            try:
                data_formatada = datetime.strptime(str(data_sem_formatacao), '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y')
            except (ValueError, TypeError):
                data_formatada = str(data_sem_formatacao)

        resultado.append({
            'data_doacao': data_formatada,
            'valor': float(d[1]),
            'nome_ong': d[2],
            'nome_doador': d[3]
        })

    return jsonify(resultado)

@app.route('/postagem_projeto_geral', methods=['GET'])
def retorna_projeto_geral():
    cur = con.cursor()
    cur.execute("""
        SELECT p.id_projeto, p.descricao, p.data_projeto, p.id_usuario, u.nome 
        FROM projeto p
        LEFT JOIN usuario u ON p.id_usuario = u.id_usuario
    """)
    projetos = cur.fetchall()
    cur.close()

    projetos_dic = []

    for projeto in projetos:
        id_projeto = projeto[0]
        descricao = projeto[1]
        data_projeto = projeto[2]
        id_usuario = projeto[3]
        nome = projeto[4]

        if isinstance(data_projeto, str): #Isinstance serve para verificar se um objeto é de um tipo específico (ou de uma tupla de tipos)
            try:
                data_projeto = datetime.strptime(data_projeto, "%d/%m/%Y %H:%M")
            except:
                try:
                    data_projeto = datetime.fromisoformat(data_projeto) #fromisoformat: Converte uma String do formato ISO 8601 em um objeto datetime ou date
                except:
                    data_projeto = datetime.now()

        locale.setlocale(locale.LC_TIME, 'pt_BR.UTF-8')
        if data_projeto is not None:
            # Formatar a data com o mês por extenso e hora
            data_formatada = f"Publicado em {data_projeto.day} de {data_projeto.strftime('%B')} de {data_projeto.year} às {data_projeto.strftime('%H:%M')}"
        else:
            data_formatada = "Data não disponível"

        # Adicionando o projeto à lista
        projetos_dic.append({
            'id_projeto': id_projeto,
            'data_projeto': data_formatada,
            'descricao': descricao,
            'id_usuario': id_usuario,
            'nome': nome
        })

    if projetos_dic:
        return jsonify(mensagem='Registro de Postagens', projetos=projetos_dic)
    else:
        return jsonify(mensagem='Nenhum dado encontrado')


@app.route('/postagem_projeto/<int:id_usuario>', methods=['GET'])
def retorna_projeto(id_usuario):
    cur = con.cursor()
    cur.execute("""
        SELECT p.id_projeto, p.descricao, p.data_projeto, p.id_usuario, u.nome 
        FROM projeto p
        LEFT JOIN usuario u ON p.id_usuario = u.id_usuario
        WHERE p.id_usuario = ?
    """, (id_usuario,))
    projetos = cur.fetchall()
    cur.close()

    projetos_dic = []

    for projeto in projetos:
        id_projeto = projeto[0]
        descricao = projeto[1]
        data_projeto = projeto[2]
        id_usuario = projeto[3]
        nome = projeto[4]

        if isinstance(data_projeto, str): #Isinstance serve para verificar se um objeto é de um tipo específico (ou de uma tupla de tipos)
            try:
                data_projeto = datetime.strptime(data_projeto, "%d/%m/%Y %H:%M")
            except:
                try:
                    data_projeto = datetime.fromisoformat(data_projeto) #fromisoformat: Converte uma String do formato ISO 8601 em um objeto datetime ou date
                except:
                    data_projeto = datetime.now()

        locale.setlocale(locale.LC_TIME, 'pt_BR.UTF-8')
        if data_projeto is not None:
            # Formatar a data com o mês por extenso e hora
            data_formatada = f"Publicado em {data_projeto.day} de {data_projeto.strftime('%B')} de {data_projeto.year} às {data_projeto.strftime('%H:%M')}"
        else:
            data_formatada = "Data não disponível"

        # Adicionando o projeto à lista
        projetos_dic.append({
            'id_projeto': id_projeto,
            'data_projeto': data_formatada,
            'descricao': descricao,
            'id_usuario': id_usuario,
            'nome': nome
        })

    if projetos_dic:
        return jsonify(mensagem='Registro de Postagens', projetos=projetos_dic)
    else:
        return jsonify(mensagem='Nenhum dado encontrado')


@app.route('/postagem_projeto', methods=['POST'])
def postagem_projeto():
    data_projeto = request.form.get('data_projeto')
    descricao = request.form.get('descricao')
    id_usuario = request.form.get('id_usuario')
    imagem = request.files.get('imagem')

    if not data_projeto:
        data_projeto = datetime.now()

    cursor = con.cursor()
    cursor.execute("INSERT INTO PROJETO(DATA_PROJETO, DESCRICAO, id_usuario) VALUES (?, ?, ?) returning id_projeto",
                   (data_projeto, descricao, id_usuario))
    id_projeto = cursor.fetchone()[0]  # Buscar antes do commit
    con.commit()
    cursor.close()

    imagem_path = None #caminho da imagem
    if imagem:
        nome_imagem = f"{id_projeto}.jpeg"
        pasta_destino = os.path.join(app.config['UPLOAD_FOLDER'], "Projetos") # definindo a pasta de destino dessa imagem 'projetos'
        os.makedirs(pasta_destino, exist_ok=True) #criando a pasta
        imagem_path = os.path.join(pasta_destino, nome_imagem) #juntando o caminho com o nome da imagem
        imagem.save(imagem_path)

    return jsonify({
        'message': "Postagem realizada com sucesso!",
        'postagem': {
            'id_projeto': id_projeto,
            'data_projeto': data_projeto,
            'descricao': descricao,
            'imagem_path': imagem_path
        }
    })

@app.route('/postagem_projeto/<int:id>', methods=['PUT'])
def edicao_projeto(id):
    cursor = con.cursor()
    try:
        cursor.execute(
            "SELECT id_projeto, data_projeto, descricao FROM projeto WHERE id_projeto = ?",
            (id,))
        projeto = cursor.fetchone()

        if not projeto:
            return jsonify({"error": "Projeto não encontrado."}), 401

        data_projeto_armazenada = projeto[1]
        descricao_armazenada = projeto[2]

        # data = request.get_json()
        data_projeto = request.form.get('data_projeto')
        descricao = request.form.get('descricao')
        imagem = request.files.get('imagem')

        if data_projeto is None:
            data_projeto = data_projeto_armazenada

        if descricao is None:
            descricao = descricao_armazenada

        cursor.execute(
            "UPDATE projeto SET data_projeto = ?, descricao = ? WHERE id_projeto = ?",
            (data_projeto, descricao, id))
        con.commit()

        imagem_path = None
        if imagem:
            nome_imagem = f"{id}.jpeg"  # Define o nome fixo com .jpeg
            pasta_destino = os.path.join(app.config['UPLOAD_FOLDER'], "Projetos")
            os.makedirs(pasta_destino, exist_ok=True)
            imagem_path = os.path.join(pasta_destino, nome_imagem)
            imagem.save(imagem_path)

        return jsonify({
            'message': "Projeto atualizado com sucesso!",
            'projeto': {
                'id_projeto': id,
                'data_projeto': data_projeto,
                'descricao': descricao,
                'imagem_path': imagem_path
            }
        }), 200
    finally:
        if cursor:
            cursor.close()


@app.route('/postagem_projeto/<int:id>', methods=['DELETE'])
def deletar_projeto(id):
    cursor = con.cursor()
    try:

        cursor.execute("SELECT 1 FROM projeto WHERE id_projeto = ?", (id,))
        if not cursor.fetchone():
            return jsonify({"error": "Projeto não encontrado."}), 404

        cursor.execute("DELETE FROM projeto WHERE id_projeto = ?", (id,))
        con.commit()

        return jsonify({
            'message': "Projeto excluído com sucesso!",
            'id_projeto': id
        })
    finally:
        if cursor:
            cursor.close()

@app.route('/aprovacao_ong', methods=['GET'])
def aprovacao_ong():
    cursor = con.cursor()
    cursor.execute("SELECT id_usuario, nome, e_mail, senha, tipo, ativo, cnpj, categoria, descricao_da_causa, cep, chave_pix, num_agencia, num_conta, nome_banco, endereco, complemento, nome_resp, telefone, site_url, facebook, instagram, cidade, aprovada FROM USUARIO WHERE TIPO  = 2 AND coalesce(aprovada, 0) = 0")
    usuarios = cursor.fetchall()
    cursor.close()

    usuarios_dic = []

    for usuario in usuarios:
        id_usuario = usuario[0]
        nome = usuario[1]
        e_mail = usuario[2]
        senha = usuario[3]
        tipo = usuario[4]
        ativo = usuario[5]
        cnpj = usuario[6]
        categoria = usuario[7]
        descricao_da_causa = usuario[8]
        cep = usuario[9]
        chave_pix = usuario[10]
        num_agencia = usuario[11]
        num_conta = usuario[12]
        nome_banco = usuario[13]
        endereco = usuario[14]
        complemento = usuario[15]
        nome_resp = usuario[16]
        telefone = usuario[17]
        site_url = usuario[18]
        facebook = usuario[19]
        instagram = usuario[20]
        cidade = usuario[21]
        aprovada = usuario[22]

        usuarios_dic.append({
            'id_usuario': id_usuario,
            'nome': nome,
            'e_mail': e_mail,
            'senha': senha,
            'tipo': tipo,
            'ativo': ativo,
            'cnpj': cnpj,
            'categoria': categoria,
            'descricao_da_causa': descricao_da_causa,
            'cep': cep,
            'chave_pix': chave_pix,
            'num_agencia': num_agencia,
            'num_conta': num_conta,
            'nome_banco': nome_banco,
            'endereco': endereco,
            'complemento': complemento,
            'nome_resp': nome_resp,
            'telefone': telefone,
            'site_url': site_url,
            'facebook': facebook,
            'instagram': instagram,
            'cidade': cidade,
            'aprovada': aprovada
        })

    if usuarios_dic:
        return jsonify(mensagem='ONGs não aprovadas', usuarios=usuarios_dic)
    else:
        return jsonify(mensagem='Não restam ONGs sem aprovação')


@app.route('/aprovacao/<int:id>', methods=['PUT'])
def aprovacao(id):
    data = request.get_json()
    aprovada = data.get('aprovada')
    cursor = con.cursor()
    try:
        cursor.execute(
            """
            SELECT id_usuario, nome, e_mail, senha, tipo, ativo, cnpj, categoria, descricao_da_causa,
                   cep, chave_pix, num_agencia, num_conta, nome_banco, endereco, complemento,
                   nome_resp, telefone, site_url, facebook, instagram, cidade, aprovada
            FROM USUARIO
            WHERE TIPO = 2 AND coalesce(aprovada, 0) = 0 AND id_usuario = ?
            """, (id,)
        )
        usuario = cursor.fetchone()


        if not usuario:
            return jsonify({"error": "Não há ONGs pendentes de aprovação com esse ID."}), 404

        # Desempacotando os dados do banco
        (id_usuario, nome_db, e_mail_db, senha_db, tipo_db, ativo_db, cnpj_db, categoria_db,
         descricao_db, cep_db, chave_pix_db, num_agencia_db, num_conta_db, nome_banco_db,
         endereco_db, complemento_db, nome_resp_db, telefone_db, site_url_db, facebook_db,
         instagram_db, cidade_db, aprovada_db) = usuario

        # Dados do request
        data = request.get_json()

        nome = data.get('nome', nome_db)
        e_mail = data.get('e_mail', e_mail_db)
        senha = data.get('senha', senha_db)
        cnpj = data.get('cnpj', cnpj_db)
        categoria = data.get('categoria', categoria_db)
        descricao_da_causa = data.get('descricao_da_causa', descricao_db)
        cep = data.get('cep', cep_db)
        chave_pix = data.get('chave_pix', chave_pix_db)
        num_agencia = data.get('num_agencia', num_agencia_db)
        num_conta = data.get('num_conta', num_conta_db)
        nome_banco = data.get('nome_banco', nome_banco_db)
        endereco = data.get('endereco', endereco_db)
        complemento = data.get('complemento', complemento_db)
        nome_resp = data.get('nome_resp', nome_resp_db)
        telefone = data.get('telefone', telefone_db)
        site_url = data.get('site_url', site_url_db)
        facebook = data.get('facebook', facebook_db)
        instagram = data.get('instagram', instagram_db)
        cidade = data.get('cidade', cidade_db)
        tipo = data.get('tipo', tipo_db)
        ativo = data.get('ativo', ativo_db)

        if aprovada == 1:
        # Atualização de aprovação
            cursor.execute(
                "UPDATE usuario SET aprovada = 1 WHERE tipo = 2 AND ID_USUARIO = ?",
                (id,)
            )
            con.commit()

            return jsonify({"message": f"ONG com ID {id} aprovada com sucesso."}), 200
        else:

            cursor.execute(
                "UPDATE usuario SET ativo = 0 WHERE tipo = 2 AND ID_USUARIO = ?",
                (id,)
            )
            con.commit()


            return jsonify({"message": f"ONG com ID {id} não aprovada."}), 200

    except Exception as e:
        return jsonify({"error": "Erro interno no servidor.", "details": str(e)}), 500
    finally:
        if cursor:
            cursor.close()

@app.route('/alterandoativo/<int:id>', methods=['PUT'])
def alterar_ativo(id):
       cursor = con.cursor()
       try:
           cursor.execute("SELECT ativo FROM usuario WHERE id_usuario = ?", (id,))
           resultado = cursor.fetchone()


           if not resultado:
               return jsonify({'error': 'Usuário não encontrado.'}), 404

           ativo_atual = resultado[0]

           if ativo_atual == 1:
               ativo_alterado = 0
           elif ativo_atual == 0:
               ativo_alterado = 1

           cursor.execute("UPDATE usuario SET ativo = ? WHERE id_usuario = ?", (ativo_alterado, id))
           con.commit()

           return jsonify({
               'message': f'Status de atividade atualizado!',
               'id_usuario': id,
               'ativo': ativo_alterado
           }), 200
       finally:
           if cursor:
               cursor.close()